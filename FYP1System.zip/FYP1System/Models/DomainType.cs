﻿namespace FYP1System.Models
{
    public enum DomainType
    {
        Research,
        Development
    }
}

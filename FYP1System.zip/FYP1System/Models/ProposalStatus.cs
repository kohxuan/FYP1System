﻿using System.ComponentModel.DataAnnotations;

namespace FYP1System.Models
{
    public enum ProposalStatus
    {
        Accepted,
        [Display(Name = "Accepted With Conditions")]
        AcceptedWithConditions,
        Rejected
    }
}

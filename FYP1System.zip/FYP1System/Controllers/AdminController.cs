using FYP1System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace FYP1System.Controllers
{
    public class AdminController : Controller
    {
        private readonly FYP1SystemContext _context;

        public AdminController(FYP1SystemContext context)
        {
            _context = context;
        }

        private bool IsAuthorized(string role)
        {
            var roles = HttpContext.Session.GetString("Roles");
            return roles != null && roles.Split(',').Contains(role, StringComparer.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> Index()
        {
            if (!IsAuthorized("Admin")) return RedirectToAction("Index", "Home");

            var totalPrograms = await _context.AcademicPrograms.CountAsync();
            var totalLecturers = await _context.Lecturers.CountAsync();

            var lecturers = await _context.Lecturers.ToListAsync();

            var totalCommittees = lecturers
                .Where(l => l.Role != null && l.Role.Split(',').Contains("Committee"))
                .Count();

            ViewBag.TotalPrograms = totalPrograms;
            ViewBag.TotalLecturers = totalLecturers;
            ViewBag.TotalCommittees = totalCommittees;

            return View();
        }


        public async Task<IActionResult> ManageCommittees()
        {
            if (!IsAuthorized("Admin")) return RedirectToAction("Index", "Home");

            var lecturer = await _context.Lecturers.Include(l => l.Program).ToListAsync();
            return View(lecturer);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCommitteeMembers(List<int> committeeMembers)
        {
            if (!IsAuthorized("Admin")) return RedirectToAction("Index", "Home");

            var allLecturers = await _context.Lecturers.ToListAsync();

            foreach (var lecturer in allLecturers)
            {
                if (committeeMembers.Contains(lecturer.Id))
                {
                    // Should be committee member
                    if (!lecturer.HasRole("Committee"))
                    {
                        lecturer.AddRole("Committee");
                        _context.Update(lecturer);
                    }
                }
                else
                {
                    // Should not be committee member
                    if (lecturer.HasRole("Committee"))
                    {
                        lecturer.RemoveRole("Committee");
                        _context.Update(lecturer);
                    }
                }
            }

            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Committee members updated successfully!";
            return RedirectToAction("ManageCommittees");
        }
    }
}

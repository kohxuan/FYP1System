using FYP1System.Models;
using Microsoft.EntityFrameworkCore;

namespace FYP1System.Data
{
    public static class DbInitializer
    {
        public static async Task Initialize(FYP1SystemContext context)
        {
            // Ensure database is created
            await context.Database.EnsureCreatedAsync();

            // Check if data already exists
            if (await context.AcademicPrograms.AnyAsync() && await context.Lecturers.AnyAsync())
            {
                return; // Database has been seeded
            }

            // 1. Create Academic Programs
            var programs = new AcademicProgram[]
            {
                new AcademicProgram { Name = "Data Engineering" },
                new AcademicProgram { Name = "Software Engineering" }
            };

            await context.AcademicPrograms.AddRangeAsync(programs);
            await context.SaveChangesAsync();

            // Get program IDs after saving
            var dataEngProgram = await context.AcademicPrograms.FirstAsync(p => p.Name == "Data Engineering");
            var softEngProgram = await context.AcademicPrograms.FirstAsync(p => p.Name == "Software Engineering");

            // 2. Check if Admin User exists, create if not
            if (!await context.Users.AnyAsync(u => u.Email == "admin@fyp.edu.my"))
            {
                var adminUser = new User
                {
                    Name = "System Administrator",
                    Email = "admin@fyp.edu.my",
                    Password = "admin123",
                    Role = "Admin"
                };
                await context.Users.AddAsync(adminUser);
                await context.SaveChangesAsync();
            }

            // 3. Check if Lecturer Users exist, create if not
            if (!await context.Users.AnyAsync(u => u.Role.Contains("Lecturer")))
            {
                var lecturerUsers = new User[]
                {
                    // Data Engineering Lecturers
                    new User { Name = "Dr. Ahmad Rahman", Email = "ahmad.rahman@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Committee" },
                    new User { Name = "Dr. Siti Nurhaliza", Email = "siti.nurhaliza@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Supervisor" },
                    new User { Name = "Prof. Lim Wei Ming", Email = "lim.weiming@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Evaluator" },
                    new User { Name = "Dr. Raj Kumar", Email = "raj.kumar@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Supervisor,Evaluator" },
                    
                    // Software Engineering Lecturers  
                    new User { Name = "Dr. Sarah Johnson", Email = "sarah.johnson@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Committee" },
                    new User { Name = "Prof. Chen Li Hua", Email = "chen.lihua@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Supervisor" },
                    new User { Name = "Dr. Muhammad Farid", Email = "muhammad.farid@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Evaluator" },
                    new User { Name = "Dr. Priya Sharma", Email = "priya.sharma@fyp.edu.my", Password = "lecturer123", Role = "Lecturer,Supervisor,Evaluator" }
                };

                await context.Users.AddRangeAsync(lecturerUsers);
                await context.SaveChangesAsync();
            }

            // Get lecturer user IDs
            var lecturerUserIds = await context.Users
                .Where(u => u.Role.Contains("Lecturer"))
                .Select(u => u.Id)
                .ToListAsync();

            // 4. Create Lecturer entities with domains (only if they don't exist)
            if (!await context.Lecturers.AnyAsync())
            {
                var lecturers = new List<Lecturer>();
                
                // Data Engineering Lecturers
                lecturers.Add(new Lecturer { Id = lecturerUserIds[0], Domain = DomainType.Research, ProgramId = dataEngProgram.Id }); // Dr. Ahmad (Committee)
                lecturers.Add(new Lecturer { Id = lecturerUserIds[1], Domain = DomainType.Research, ProgramId = dataEngProgram.Id }); // Dr. Siti (Supervisor)
                lecturers.Add(new Lecturer { Id = lecturerUserIds[2], Domain = DomainType.Development, ProgramId = dataEngProgram.Id }); // Prof. Lim (Evaluator)
                lecturers.Add(new Lecturer { Id = lecturerUserIds[3], Domain = DomainType.Research, ProgramId = dataEngProgram.Id }); // Dr. Raj (Both)
                
                // Software Engineering Lecturers
                lecturers.Add(new Lecturer { Id = lecturerUserIds[4], Domain = DomainType.Development, ProgramId = softEngProgram.Id }); // Dr. Sarah (Committee)
                lecturers.Add(new Lecturer { Id = lecturerUserIds[5], Domain = DomainType.Development, ProgramId = softEngProgram.Id }); // Prof. Chen (Supervisor)
                lecturers.Add(new Lecturer { Id = lecturerUserIds[6], Domain = DomainType.Research, ProgramId = softEngProgram.Id }); // Dr. Muhammad (Evaluator)
                lecturers.Add(new Lecturer { Id = lecturerUserIds[7], Domain = DomainType.Development, ProgramId = softEngProgram.Id }); // Dr. Priya (Both)

                await context.Lecturers.AddRangeAsync(lecturers);
                await context.SaveChangesAsync();
            }

            // 5. Check if Student Users exist, create if not
            if (!await context.Users.AnyAsync(u => u.Role == "Student"))
            {
                var studentUsers = new User[]
                {
                    // Data Engineering Students
                    new User { Name = "Ali bin Ahmad", Email = "ali.ahmad@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    new User { Name = "Nurul Aina", Email = "nurul.aina@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    new User { Name = "Chong Wei Lun", Email = "chong.weilun@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    new User { Name = "Kavitha Devi", Email = "kavitha.devi@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    
                    // Software Engineering Students
                    new User { Name = "Ahmad Zaki", Email = "ahmad.zaki@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    new User { Name = "Lim Mei Ling", Email = "lim.meiling@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    new User { Name = "Rajesh Kumar", Email = "rajesh.kumar@student.fyp.edu.my", Password = "student123", Role = "Student" },
                    new User { Name = "Fatimah Zahra", Email = "fatimah.zahra@student.fyp.edu.my", Password = "student123", Role = "Student" }
                };

                await context.Users.AddRangeAsync(studentUsers);
                await context.SaveChangesAsync();
            }

            // Get student user IDs
            var studentUserIds = await context.Users
                .Where(u => u.Role == "Student")
                .Select(u => u.Id)
                .ToListAsync();

            // 6. Create Student entities (only if they don't exist)
            if (!await context.Students.AnyAsync())
            {
                var students = new List<Student>();
                
                // Data Engineering Students
                students.Add(new Student { Id = studentUserIds[0], ProgramId = dataEngProgram.Id }); // Ali
                students.Add(new Student { Id = studentUserIds[1], ProgramId = dataEngProgram.Id }); // Nurul
                students.Add(new Student { Id = studentUserIds[2], ProgramId = dataEngProgram.Id }); // Chong
                students.Add(new Student { Id = studentUserIds[3], ProgramId = dataEngProgram.Id }); // Kavitha
                
                // Software Engineering Students
                students.Add(new Student { Id = studentUserIds[4], ProgramId = softEngProgram.Id }); // Ahmad Zaki
                students.Add(new Student { Id = studentUserIds[5], ProgramId = softEngProgram.Id }); // Lim Mei Ling
                students.Add(new Student { Id = studentUserIds[6], ProgramId = softEngProgram.Id }); // Rajesh
                students.Add(new Student { Id = studentUserIds[7], ProgramId = softEngProgram.Id }); // Fatimah

                await context.Students.AddRangeAsync(students);
                await context.SaveChangesAsync();
            }

            // 7. Create Sample Proposals with different statuses (only if they don't exist)
            if (!await context.Proposals.AnyAsync())
            {
                var proposals = new List<Proposal>();
                
                // Get lecturer IDs for assignments
                var dataEngLecturers = await context.Lecturers.Where(l => l.ProgramId == dataEngProgram.Id).ToListAsync();
                var softEngLecturers = await context.Lecturers.Where(l => l.ProgramId == softEngProgram.Id).ToListAsync();
            
            // Data Engineering Proposals
            proposals.Add(new Proposal
            {
                Title = "Big Data Analytics for Smart City Traffic Management",
                ProjectType = DomainType.Research,
                Semester = "2024/2025-1",
                Session = "2024/2025",
                StudentId = studentUserIds[0], // Ali
                SupervisorId = dataEngLecturers.First(l => l.Domain == DomainType.Research && l.Id != dataEngLecturers[0].Id).Id, // Dr. Siti or Dr. Raj
                SupervisorStatus = SupervisorStatus.SupervisorApproved,
                EvaluationStatus = ProposalStatus.Accepted,
                EvaluatorComment = "Excellent research proposal with clear methodology and objectives.",
                Evaluator1Id = dataEngLecturers.First(l => l.Domain == DomainType.Development).Id, // Prof. Lim
                Evaluator2Id = dataEngLecturers.First(l => l.Domain == DomainType.Research && l.Id != dataEngLecturers[1].Id).Id
            });

            proposals.Add(new Proposal
            {
                Title = "Machine Learning Model for Predictive Maintenance in Manufacturing",
                ProjectType = DomainType.Development,
                Semester = "2024/2025-1",
                Session = "2024/2025",
                StudentId = studentUserIds[1], // Nurul
                SupervisorId = dataEngLecturers.First(l => l.Domain == DomainType.Research).Id,
                SupervisorStatus = SupervisorStatus.SupervisorApproved,
                EvaluationStatus = ProposalStatus.AcceptedWithConditions,
                EvaluatorComment = "Good proposal but needs more detailed timeline and risk assessment.",
                Evaluator1Id = dataEngLecturers.First(l => l.Domain == DomainType.Development).Id,
                Evaluator2Id = dataEngLecturers.Last().Id
            });

            // Software Engineering Proposals
            proposals.Add(new Proposal
            {
                Title = "Mobile Application for University Event Management System",
                ProjectType = DomainType.Development,
                Semester = "2024/2025-1",
                Session = "2024/2025",
                StudentId = studentUserIds[4], // Ahmad Zaki
                SupervisorId = softEngLecturers.First(l => l.Domain == DomainType.Development && l.Id != softEngLecturers[0].Id).Id, // Prof. Chen or Dr. Priya
                SupervisorStatus = SupervisorStatus.SupervisorApproved,
                EvaluationStatus = ProposalStatus.Rejected,
                EvaluatorComment = "Proposal lacks technical depth and innovation. Please revise with more advanced features.",
                Evaluator1Id = softEngLecturers.First(l => l.Domain == DomainType.Research).Id, // Dr. Muhammad
                Evaluator2Id = softEngLecturers.First(l => l.Domain == DomainType.Development && l.Id != softEngLecturers[1].Id).Id
            });

            proposals.Add(new Proposal
            {
                Title = "Web-based Learning Management System with AI Chatbot",
                ProjectType = DomainType.Development,
                Semester = "2024/2025-1",
                Session = "2024/2025",
                StudentId = studentUserIds[5], // Lim Mei Ling
                TentativeSupervisorId = softEngLecturers.First(l => l.Domain == DomainType.Development).Id,
                SupervisorStatus = SupervisorStatus.SupervisorSelectionPendingApproval,
                SupervisorComment = "Interesting project idea. Looking forward to supervising this."
            });

            // Proposals pending supervisor selection
            proposals.Add(new Proposal
            {
                Title = "IoT-based Smart Home Automation System",
                ProjectType = DomainType.Development,
                Semester = "2024/2025-1",
                Session = "2024/2025",
                StudentId = studentUserIds[2], // Chong
                SupervisorStatus = SupervisorStatus.PendingSupervisorSelection
            });

            proposals.Add(new Proposal
            {
                Title = "Blockchain-based Supply Chain Management System",
                ProjectType = DomainType.Research,
                Semester = "2024/2025-1",
                Session = "2024/2025",
                StudentId = studentUserIds[6], // Rajesh
                SupervisorStatus = SupervisorStatus.PendingSupervisorSelection
            });

                await context.Proposals.AddRangeAsync(proposals);
                await context.SaveChangesAsync();
            }

            Console.WriteLine("Database seeded successfully!");
            Console.WriteLine("\n=== SEEDED TEST CREDENTIALS ===");
            Console.WriteLine("\n🔑 ADMIN:");
            Console.WriteLine("Email: admin@fyp.edu.my");
            Console.WriteLine("Password: admin123");
            
            Console.WriteLine("\n👨‍🏫 LECTURERS (Committee/Supervisor/Evaluator):");
            Console.WriteLine("Data Engineering:");
            Console.WriteLine("- ahmad.rahman@fyp.edu.my / lecturer123 (Committee)");
            Console.WriteLine("- siti.nurhaliza@fyp.edu.my / lecturer123 (Supervisor)");
            Console.WriteLine("- lim.weiming@fyp.edu.my / lecturer123 (Evaluator)");
            Console.WriteLine("- raj.kumar@fyp.edu.my / lecturer123 (Supervisor + Evaluator)");
            
            Console.WriteLine("Software Engineering:");
            Console.WriteLine("- sarah.johnson@fyp.edu.my / lecturer123 (Committee)");
            Console.WriteLine("- chen.lihua@fyp.edu.my / lecturer123 (Supervisor)");
            Console.WriteLine("- muhammad.farid@fyp.edu.my / lecturer123 (Evaluator)");
            Console.WriteLine("- priya.sharma@fyp.edu.my / lecturer123 (Supervisor + Evaluator)");
            
            Console.WriteLine("\n🎓 STUDENTS:");
            Console.WriteLine("Data Engineering:");
            Console.WriteLine("- ali.ahmad@student.fyp.edu.my / student123");
            Console.WriteLine("- nurul.aina@student.fyp.edu.my / student123");
            Console.WriteLine("- chong.weilun@student.fyp.edu.my / student123");
            Console.WriteLine("- kavitha.devi@student.fyp.edu.my / student123");
            
            Console.WriteLine("Software Engineering:");
            Console.WriteLine("- ahmad.zaki@student.fyp.edu.my / student123");
            Console.WriteLine("- lim.meiling@student.fyp.edu.my / student123");
            Console.WriteLine("- rajesh.kumar@student.fyp.edu.my / student123");
            Console.WriteLine("- fatimah.zahra@student.fyp.edu.my / student123");
            
            Console.WriteLine("\n📋 SAMPLE DATA CREATED:");
            Console.WriteLine("- 2 Academic Programs (Data Engineering, Software Engineering)");
            Console.WriteLine("- 8 Lecturers with different roles and domains");
            Console.WriteLine("- 8 Students across both programs");
            Console.WriteLine("- 6 Sample proposals with various statuses");
            Console.WriteLine("- Committee members assigned by program");
            Console.WriteLine("- Evaluators assigned based on project domains");
        }
    }
}
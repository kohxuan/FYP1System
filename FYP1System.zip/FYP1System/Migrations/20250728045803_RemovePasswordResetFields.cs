﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FYP1System.Migrations
{
    /// <inheritdoc />
    public partial class RemovePasswordResetFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PasswordResetToken",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "PasswordResetTokenExpiry",
                table: "Students");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PasswordResetToken",
                table: "Students",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "PasswordResetTokenExpiry",
                table: "Students",
                type: "datetime2",
                nullable: true);
        }
    }
}
